# Placeholder: Use CLIP & DeepFace to extract embeddings
