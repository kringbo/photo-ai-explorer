# Placeholder: Walk through folders, extract metadata (EXIF, video info)
