# Photo AI Explorer

Local AI-powered photo and video search tool with map and face recognition.