# Placeholder: Streamlit app for search + map + manual GPS entry
